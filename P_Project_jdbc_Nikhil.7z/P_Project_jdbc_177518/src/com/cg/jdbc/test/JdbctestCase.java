package com.cg.jdbc.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class JdbctestCase {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
