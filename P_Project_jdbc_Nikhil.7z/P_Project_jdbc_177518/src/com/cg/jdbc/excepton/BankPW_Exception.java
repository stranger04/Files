package com.cg.jdbc.excepton;

public class BankPW_Exception extends Exception {

	private static final long serialVersionUID = 1L;

	public BankPW_Exception(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	

}
