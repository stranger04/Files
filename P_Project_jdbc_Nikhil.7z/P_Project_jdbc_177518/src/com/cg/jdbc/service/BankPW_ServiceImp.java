package com.cg.jdbc.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.jdbc.DAO.BankPW_DAO;
import com.cg.jdbc.DAO.BankPW_DaoImp;
import com.cg.jdbc.entity.Account;
import com.cg.jdbc.entity.Customer;
import com.cg.jdbc.excepton.BankPW_Exception;



public class BankPW_ServiceImp implements BankPW_Service {
	BankPW_DAO accDao= new BankPW_DaoImp();

	@Override
	public String createAccount(Account account, Customer customer) throws BankPW_Exception {
		accDao.createAccount(account,customer);
		return account.getContactNo();
	}

	@Override
	public Account showBalance(String accountNo) throws BankPW_Exception {
		Account account=accDao.showBalance(accountNo);
		return account;
	}

	@Override
	public Account deposite(String accountNo, double amount) throws BankPW_Exception {
		Account account=accDao.deposite(accountNo,amount);
		return account;
	}

	@Override
	public Account withDraw(String accountNo, double amount) throws BankPW_Exception {
		Account account=accDao.withDraw(accountNo,amount);
		return account;
	}

	@Override
	public Account fundTransfer(String accountNo, String accountNo1, double amount) throws BankPW_Exception {
		Account account=accDao.fundTransfer(accountNo,accountNo1,amount);
		return account;
	}
	
	
	public boolean validateContact(String contact)throws BankPW_Exception
	{
		if(Pattern.matches("[6-9]{1}[0-9]{9}", contact))
		{
			 return true;
		 }
		System.out.println("Enter 10 digit number only.");
		return false;
		
	}
	public boolean validateName(String name)throws BankPW_Exception
	{Pattern p=Pattern.compile("[A-Za-z]{2,12}");
	 Matcher m=p.matcher(name);
	 if(m.matches()) {
		 return true;
	 }
	 System.out.println("Enter charecter only.");
	return false;
		
	}
	public boolean validateAccouuntType(String acType)throws BankPW_Exception
	{
		if(acType.equals("saving") || acType.equals("current"))
		{
			 return true;
		 }
		System.out.println("Enter saving and current only.");
		return false;
		
	}

}
