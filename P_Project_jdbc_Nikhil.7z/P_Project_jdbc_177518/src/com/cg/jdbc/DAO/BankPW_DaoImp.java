package com.cg.jdbc.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.cg.jdbc.entity.Account;
import com.cg.jdbc.entity.Customer;
import com.cg.jdbc.excepton.BankPW_Exception;



public class BankPW_DaoImp implements BankPW_DAO {
	static Account account=null;
	static Connection con=null;
	static PreparedStatement pstmt= null;
	static ResultSet result=null;
	static String sql,sql1;
	
	static{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","India123" );
			con.setAutoCommit(false);
			System.out.println("Connected");
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	@Override
	public String createAccount(Account account,Customer customer) throws BankPW_Exception {
		try {
		
		sql="INSERT INTO ACCOUNT_DETAILS VALUES(?,?,?,?,?)";
		pstmt= con.prepareStatement(sql);
		
		pstmt.setString(1, account.getAccountNo());
		pstmt.setString(2, account.getName());
		pstmt.setDouble(3, account.getBalance());
		pstmt.setString(4, account.getContactNo());
		pstmt.setString(5, account.getAccountType());
		int updareRow=pstmt.executeUpdate();
		System.out.println(updareRow +" row inserted");
		
		
		sql="INSERT INTO Customer_Details VALUES(?,?,?,?,?,?)";
		pstmt= con.prepareStatement(sql);
		
		pstmt.setString(1, customer.getAccountNo());
		pstmt.setString(2, customer.getName());
		pstmt.setString(3, customer.getPanNo());
		pstmt.setString(4, customer.getAadharNo());
		pstmt.setDouble(5, customer.getBalance());
		pstmt.setString(6, customer.getAccountType());
		
		pstmt.executeUpdate();
		
		System.out.println("AccountNo:"+account.getAccountNo()+" created succesfully!!");
		con.commit();
		} 
		
		catch (SQLException e) {
			
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Account showBalance(String accountNo) throws BankPW_Exception {
		
		try {
			sql="SELECT *FROM ACCOUNT_DETAILS WHERE ACCOUNTNO =?";
			pstmt= con.prepareStatement(sql);
			pstmt.setString(1, accountNo); 
			result=pstmt.executeQuery();
			
			while (result.next()) {
				System.out.println(result.getString(1)+":"+ result.getDouble(3));
				
			}
			con.commit();
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Account deposite(String accountNo, double amount) throws BankPW_Exception {
		
		try {
			sql=" UPDATE  ACCOUNT_DETAILS SET BALANCE =(BALANCE + ?) WHERE ACCOUNTNO =?";
			pstmt= con.prepareStatement(sql);
			pstmt.setDouble(1, amount); 
			pstmt.setString(2, accountNo); 
			pstmt.executeQuery();
			con.commit();
			
		} catch (Exception e) {
			
		}
		return null;
	}

	@Override
	public Account withDraw(String accountNo, double amount) throws BankPW_Exception {

		try {
			sql=" UPDATE  ACCOUNT_DETAILS SET BALANCE =(BALANCE - ?) WHERE ACCOUNTNO =?";
			pstmt= con.prepareStatement(sql);
			pstmt.setDouble(1, amount);
			pstmt.setString(2, accountNo);
			pstmt.executeQuery(); 
			
			/*Statement stmt= con.createStatement();
			stmt.executeQuery("UPDATE  ACCOUNTDETAILS SET BALANCE =(BALANCE - amount) WHERE ACCOUNTNUMBER =accountNo");*/
			
			con.commit();
			
		} catch (Exception e) {
			
		}
		return null;
		
	}

	@Override
	public Account fundTransfer(String accountNo, String accountNo1, double amount) throws BankPW_Exception {
		try {
		sql=" UPDATE  ACCOUNT_DETAILS SET BALANCE =(BALANCE - ?) WHERE ACCOUNTNO =?";
		sql1="UPDATE  ACCOUNT_DETAILS SET BALANCE =(BALANCE + ?) WHERE ACCOUNTNO =?";
		pstmt= con.prepareStatement(sql);
		pstmt.setDouble(1, amount); 
		pstmt.setString(2, accountNo); 
		pstmt.executeQuery();
		pstmt= con.prepareStatement(sql1);
		pstmt.setDouble(1, amount); 
		pstmt.setString(2, accountNo1); 
		pstmt.executeQuery();
		con.commit();
		
		} catch (Exception e) {
			
		}
		return null;
	}

}
