package com.cg.mobshop.dto;

import java.time.LocalDate;
import java.util.Comparator;



public class Mobiles {

		private String mobileId;
		private String name;
		private String price;
		private int quantity;
		public Mobiles() {
			super();
			// TODO Auto-generated constructor stub
		}
		public Mobiles(String mobileId, String name, String price, int quantity) {
			super();
			this.mobileId = mobileId;
			this.name = name;
			this.price = price;
			this.quantity = quantity;
		}
		public String getMobileId() {
			return mobileId;
		}
		public void setMobileId(String mobileId) {
			this.mobileId = mobileId;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getPrice() {
			return price;
		}
		public void setPrice(String price) {
			this.price = price;
		}
		public int getQuantity() {
			return quantity;
		}
		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}
		@Override
		public String toString() {
			return "Mobiles [mobileId=" + mobileId + ", name=" + name + ", price=" + price + ", quantity=" + quantity
					+ "]";
		}
		

		public static Comparator<Mobiles>   getcompname() {
			Comparator<Mobiles> comp=new Comparator<Mobiles>() {
				@Override
				public int compare(Mobiles o1, Mobiles o2) {
					return o1.name.compareTo(o2.name);
				}
					};
					return comp;
		}
		
		
		public static Comparator<Mobiles> sortbyID()
		{
			Comparator<Mobiles> comp2=new Comparator<Mobiles>() {
		@Override
		public int compare(Mobiles k1, Mobiles k2) {
			return k1.mobileId.compareTo(k2.mobileId);
		}
			};
			return comp2;
		}
		
		
		public static Comparator<Mobiles> getcompPrice() {
			Comparator<Mobiles> comp1=new Comparator<Mobiles>() {
				@Override
				public int compare(Mobiles z1, Mobiles z2) {
					return  z1.price.compareTo(z2.price);
				}
					};
					return comp1;

		}
		
		
		
	
}
