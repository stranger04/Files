package com.cg.mobshop.ui;

import java.security.Provider.Service;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Map.Entry;


import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.exception.MobileException;
import com.cg.mobshop.service.MobileServiceImpl;

public class MainUI {
		static Scanner sc = null;
		static MobileServiceImpl cs = null;

		public static void main(String[] args) throws MobileException {
			sc = new Scanner(System.in);
			cs = new MobileServiceImpl();
			int choice = 0;
			System.out.println("Welcome to the Mobile Shopee");
			System.out.println("Do you want to Display the available mobiles\n 1.yes\n 2.No");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				getMobileList();
				break;
			case 2:
				System.out.println("Thank you");
				break;
			}
			System.out.println("");
			System.out.println("Which operations do you want to perform?");
			System.out.println("1.Sorting\n2.Delete Mobile");
			System.out.println("Select sorting criteria:\n 1.Mobile name\n2.Mobile Price\n3.Mobile Quantity");
			System.out.println("4.Delete Mobile");
			while (true) {
				System.out.println("Enter Your Choice");
				
				choice = sc.nextInt();
				switch (choice) {
				case 1:
					sortMobilebyName();
					break;
				case 2:
					sortMobilebyPrice();
					break;
				case 3:
					sortBymobId();
					break;
				case 4:
					deleteMobile();
					break;
}
			}
		}
		
		
		
		private static void deleteMobile() {
			System.out.println("Enter the employee Id to to delete employee");
			String mobileId = sc.next();
			String mob=cs.deleteMobile(mobileId);

			System.out.println("Employee has been removed ");
			
		}



		private static void sortMobilebyName() {
			List<Mobiles> l=cs.sortMobilebyName();
			System.out.println("sorting of Mobile by Name");
					Iterator<Mobiles> i=l.iterator();
					while(i.hasNext())
						{
						System.out.println(i.next());
						}
			
		}
		
		private static void sortMobilebyPrice() {
			List<Mobiles> p=cs.sortMobilebyPrice();
			System.out.println("sorting of Mobile by Price");
					Iterator<Mobiles> i=p.iterator();
					while(i.hasNext())
						{
						System.out.println(i.next());
			}
			
		}
		
		private static void sortBymobId() {
			List<Mobiles> q=cs.sortBymobId();
			System.out.println("sorting of Customers by Id");
					Iterator<Mobiles> i=q.iterator();
					while(i.hasNext())
						{
						System.out.println(i.next());
						}
		}


		private static void getMobileList() {
			List<Mobiles> r= cs.getMobileList();
			for(int i=0;i<r.size();i++)
			{
				System.out.println(r.get(i));;
			}
	}
}
