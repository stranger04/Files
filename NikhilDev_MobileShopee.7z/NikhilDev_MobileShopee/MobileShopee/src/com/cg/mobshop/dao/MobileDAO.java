package com.cg.mobshop.dao;

import java.util.List;

import com.cg.mobshop.dto.Mobiles;

public interface MobileDAO {
	public List<Mobiles> getMobileList();
	public String deleteMobile(String mobileId);
	/*public List<Mobiles>SortList();*/
	
	
	public List<Mobiles> sortBymobId();
	public List<Mobiles> sortMobilebyPrice();
	public List<Mobiles> sortMobilebyName();
}
