package com.cg.mobshop.dao;

import java.util.HashMap;
import java.util.List;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.util.Util;



public class MobileDAOImpl implements MobileDAO {

	@Override
	public List<Mobiles> getMobileList() {
		List<Mobiles> m1=Util.getMobileList();
		return (List<Mobiles>) m1;
	}

	@Override
	public String deleteMobile(String mobileId) {
		Util.deleteMobile(mobileId);
		return mobileId;
	}

/*	@Override
	public List<Mobiles> SortList() {
		List<Mobiles> a1=Util.sortbyID();
		return a1;
	}*/

	@Override
	public List<Mobiles> sortBymobId() {
		List<Mobiles> a2=Util.sortbyID();
		return a2;
	}

	@Override
	public List<Mobiles> sortMobilebyPrice() {
		List<Mobiles> e1=Util.sortbyPrice();
		return e1;
	}

	@Override
	public List<Mobiles> sortMobilebyName() {
		List<Mobiles> e=Util.SortByName();
		return e;
	}

}
