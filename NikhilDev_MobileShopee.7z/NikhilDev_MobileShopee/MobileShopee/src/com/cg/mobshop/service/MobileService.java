package com.cg.mobshop.service;

import java.util.List;

import com.cg.mobshop.dto.Mobiles;

public interface MobileService {

	public List<Mobiles> getMobileList();
	public String deleteMobile(String mobileId);
	/*public List<Mobiles>SortList();*/
	
	
	public List<Mobiles> sortBymobId();
	public List<Mobiles> sortMobilebyPrice();
	public List<Mobiles> sortMobilebyName();
}
