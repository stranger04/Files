
package com.cg.mobshop.service;

import java.util.List;


import com.cg.mobshop.dao.MobileDAO;
import com.cg.mobshop.dao.MobileDAOImpl;
import com.cg.mobshop.dto.Mobiles;

public class MobileServiceImpl implements MobileService {
	MobileDAO cd=new MobileDAOImpl();
	@Override
	public List<Mobiles> getMobileList() {
		List<Mobiles> e=cd. getMobileList();
		return e;
	}

	@Override
	public String deleteMobile(String mobileId) {
		String ob=cd.deleteMobile(mobileId);
		return ob;
	}

	/*@Override
	public List<Mobiles> SortList() {
		// TODO Auto-generated method stub
		return null;
	}*/


	@Override
	public List<Mobiles> sortMobilebyPrice() {
		List<Mobiles> e1=cd.sortMobilebyPrice();
		return e1;
	}

	@Override
	public List<Mobiles> sortMobilebyName() {
		List<Mobiles> l1=cd.sortMobilebyPrice();
		return l1;
	}

	public List<Mobiles> sortBymobId() {
		List<Mobiles> f2=cd.sortBymobId();
		return f2;
	}

	

}
