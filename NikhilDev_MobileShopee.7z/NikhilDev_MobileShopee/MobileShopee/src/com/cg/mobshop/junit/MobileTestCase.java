package com.cg.mobshop.junit;

public class MobileTestCase {

}
