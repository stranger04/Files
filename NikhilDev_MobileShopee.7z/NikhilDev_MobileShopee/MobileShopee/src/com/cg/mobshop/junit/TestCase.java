package com.cg.mobshop.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.cg.mobshop.dao.MobileDAOImpl;
import com.cg.mobshop.dto.Mobiles;

class TestCase {

	@Test
	void test() {
		fail("Not yet implemented");
	}
}
/*	public static void setUp()
	{
		MobileDAO=new MobileDAOImpl();
	} 
@Test
	public void addEmpTest() throws EmployeeException
	{
		Assert.assertEquals(111, MobileDAO.addEmployee(
				new Mobiles(111,"aaa","1111",4));
	} 
} 

}
*/