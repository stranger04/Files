package com.cg.pw.exception;

public class Bank_pw_Exception extends Exception {

	private static final long serialVersionUID = 1L;

	public Bank_pw_Exception(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
