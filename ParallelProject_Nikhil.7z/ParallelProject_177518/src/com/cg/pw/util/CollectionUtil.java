package com.cg.pw.util;



import java.util.HashMap;

import com.cg.pw.entity.Account;
import com.cg.pw.entity.Customer;

public class CollectionUtil {

	public static HashMap<Integer, Customer> hm = new HashMap<>();
	
	static 
	{
		hm.put(1001, new Customer(1001,"Nikhil","9865986598","Bellary"));
		hm.put(1002, new Customer(1002,"Shiva","8760815735","Banglore"));
		hm.put(1003, new Customer(1003,"Shantu","9876549876","Gadag"));
		hm.put(1004, new Customer(1004,"Chetan","7894567894","Hubli"));

	}
	
	public static HashMap<Integer, Account> am = new HashMap<>();
	
	static
	{
		am.put(1001, new Account (1001,"Savings","Bellary","NSSC121",25000));
		am.put(1002, new Account (1002,"Current","Bellary","NSSC121",24000));
		am.put(1003, new Account (1003,"Current","Bellary","NSSC121",23000));
		am.put(1004, new Account (1004,"Savings","Bellary","NSSC121",22000));
	
	}

	public HashMap<Integer, Account> showBalance(int accid)
	{
		if (am.containsKey(accid))
		{
			
		return am;
		}
		else
		{
			System.out.println("No such Account");
		}
		return null;		
	}

	public HashMap<Integer, Customer> validateMob(String mobno) {

		if(hm.containsValue(mobno))
				{
			System.out.println("got it");
			return hm;
				}
			return hm;
	}

	public void addCustomer(int cusid, Account account) {
		am.put(cusid, account);
		
	}

}
