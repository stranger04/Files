package com.cg.pw.junit;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import java.util.HashMap;

import org.junit.jupiter.api.Test;


import com.cg.pw.dao.Bank_pw_Dao;
import com.cg.pw.dao.Bank_pw_DaoImpl;
import com.cg.pw.entity.Account;

class Javatestcase {
	public Bank_pw_Dao dao=new Bank_pw_DaoImpl();
	@Test
	public void showBalance() {
		HashMap<Integer, Account> a=dao.showBalance(1001);
		assertEquals(new Account(1001,"Savings","Bellary","NSSC121",25000),a);
	}

}
