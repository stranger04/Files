package com.cg.pw.dao;

import java.util.HashMap;

import com.cg.pw.entity.Account;
import com.cg.pw.entity.Customer;

public interface Bank_pw_Dao {
	public void createAccount(int cusid, Account account);
	public HashMap<Integer, Account> showBalance(int accid);
	public HashMap<Integer, Customer> validateMob(String mobno);
	
	
}
