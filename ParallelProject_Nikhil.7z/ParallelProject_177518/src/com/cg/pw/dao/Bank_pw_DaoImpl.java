package com.cg.pw.dao;



import java.util.HashMap;


import com.cg.pw.entity.Account;
import com.cg.pw.entity.Customer;
import com.cg.pw.util.CollectionUtil;

public class Bank_pw_DaoImpl implements Bank_pw_Dao {

	
	CollectionUtil cu = new CollectionUtil();
	@Override
	public void createAccount(int cusid, Account account) {
		cu.addCustomer (cusid, account);
		
	}
	
	@Override
	public HashMap<Integer, Account> showBalance(int accid) {
		 HashMap<Integer, Account> w =cu.showBalance(accid);
		return w;
	}

	@Override
	public HashMap<Integer, Customer> validateMob(String mobno) {
		 HashMap<Integer, Customer>hm =cu.validateMob(mobno);
		return hm;
	}

	

}
