package com.cg.pw.entity;

public class Customer 
{
	int cusid;
	String cusname;
	String customerMobileNo;
	String customerAddress;
	public Customer(int cusid, String cusname, String customerMobileNo,
			String customerAddress) {
		super();
		this.cusid = cusid;
		this.cusname = cusname;
		this.customerMobileNo = customerMobileNo;
		this.customerAddress = customerAddress;
	}
	public int getCusid() {
		return cusid;
	}
	public void setCusid(int cusid) {
		this.cusid = cusid;
	}
	public String getCusname() {
		return cusname;
	}
	public void setCusname(String cusname) {
		this.cusname = cusname;
	}
	public String getCustomerMobileNo() {
		return customerMobileNo;
	}
	public void setCustomerMobileNo(String customerMobileNo) {
		this.customerMobileNo = customerMobileNo;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Customer [cusid=" + cusid + ", cusname=" + cusname
				+ ", customerMobileNo=" + customerMobileNo
				+ ", customerAddress=" + customerAddress + "]";
	}
	
	
}
