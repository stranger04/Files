package com.cg.pw.service;
import java.util.HashMap;

import com.cg.pw.entity.Account;
import com.cg.pw.entity.Customer;
import com.cg.pw.exception.Bank_pw_Exception;

public interface Bank_pw_Service 
{
	public  HashMap<Integer, Account> showBalance(int accid);
	HashMap<Integer, Customer> validateMob(String mobno);
	public int createAccount(int cusid,Account account);	
	public boolean validateAcctype(String acctype) throws Bank_pw_Exception;
	public boolean validateCustomerName(String cusname)  throws Bank_pw_Exception;
	public boolean validateCustomerMobileNo(String customerMobileNo) throws Bank_pw_Exception;
	public boolean validateCustomerAddress(String customerAddress) throws Bank_pw_Exception;
	
	
	
}
 