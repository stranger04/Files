package com.cg.pw.service;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.pw.dao.Bank_pw_Dao;
import com.cg.pw.dao.Bank_pw_DaoImpl;
import com.cg.pw.entity.Account;
import com.cg.pw.entity.Customer;
import com.cg.pw.exception.Bank_pw_Exception;

public class Bank_pw_ServiceImpl implements Bank_pw_Service
{
	Bank_pw_Dao cusdao = new Bank_pw_DaoImpl();
	
	@Override
	public boolean validateCustomerName(String cusname) throws Bank_pw_Exception {
		Pattern pattern = Pattern.compile("^[A-Za-z]{4,10}");
		Matcher cusnameMatch = pattern.matcher(cusname);
		if (cusnameMatch.matches())
		{
			return true;
		}
		return false;
	}

	@Override
	public boolean validateCustomerMobileNo(String customerMobileNo) throws Bank_pw_Exception {
		Pattern pattern = Pattern.compile("^[0-9]{10}");
		Matcher customerMobileNoMatch = pattern.matcher(customerMobileNo);
		if (customerMobileNoMatch.matches())
		{
			return true;
		}
		return false;
	}

	@Override
	public boolean validateCustomerAddress(String customerAddress) throws Bank_pw_Exception {
		Pattern pattern = Pattern.compile("^[A-Za-z]{3,20}");
		Matcher customerAddressMatch = pattern.matcher(customerAddress);
		if (customerAddressMatch.matches())
		{
			return true;
		}
		return false;
	}
	@Override
	public boolean validateAcctype(String acctype) throws Bank_pw_Exception 
	{	
		String a1="Savings";
		String a2="Current";
		if (acctype.equals(a1) || acctype.equals(a2))
		{
			return true;
		}
		return false;
	}
	
	@Override
	public HashMap<Integer, Account> showBalance(int accid) {
		 HashMap<Integer, Account> w= cusdao.showBalance(accid);
		return w;
	}

	@Override
	public HashMap<Integer, Customer> validateMob(String mobno) {
		HashMap<Integer, Customer>hm= cusdao.validateMob(mobno);
		return hm;
	}

	@Override
	public int createAccount(int cusid, Account account) {
		cusdao.createAccount( cusid, account);
		return 0;
	}

}
