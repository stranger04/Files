package com.cg.ac.service;

import com.cg.ac.bean.Account;
import com.cg.ac.bean.Customer;
import com.cg.ac.exception.AccountException;

public interface AccountService {
	public String createAccount(Account account,Customer customer)throws AccountException;
	public Account showBalance(String accountNo)throws AccountException;
	public Account deposite(String accountNo, double amount)throws AccountException;
	public Account withDraw(String accountNo, double amount)throws AccountException;
	public Account fundTransfer(String accountNo,String accountNo1, double amount) throws AccountException;
	public boolean validateContact(String contact)throws AccountException;
	public boolean validateName(String name)throws AccountException;
	public boolean validateAccouuntType(String acType)throws AccountException;
	public boolean validateAadhar(String acType)throws AccountException;
	

}
