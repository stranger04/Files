package com.cg.ac.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.ac.bean.Account;
import com.cg.ac.bean.Customer;
import com.cg.ac.exception.AccountException;

public class AccountDaoImp implements AccountDao {
	Account account= new Account();
	Account account1= new Account();
	
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em = factory.createEntityManager();
	
	@Override
	public String createAccount(Account account,Customer customer) throws AccountException {
	this.account=account;
	em.getTransaction().begin();
		em.persist(account);
		em.persist(customer);
		em.getTransaction().commit();
		em.close();
		factory.close();
		return account.getAccountNo();
	}

	@Override
	public Account showBalance(String accountNo) throws AccountException {
		if(em.find(Account.class, accountNo)!=null)
		{
			account=em.find(Account.class, accountNo);
			System.out.println(account.getBalance());
		}
		else {
			System.out.println("Use does't exist.");
		}
		
		
		
		return account;
	}

	@Override
	public Account deposite(String accountNo, double amount) throws AccountException {
		em.getTransaction().begin();
		if(em.find(Account.class, accountNo)!=null)
		{
			account=em.find(Account.class, accountNo);
			amount=account.getBalance()+amount;
			account.setBalance(amount);
		}
		else {
			System.out.println("Use does't exist.");
		}
		
		em.getTransaction().commit();
		/*em.close();
		factory.close();*/
		return account;
	}

	@Override
	public Account withDraw(String accountNo, double amount) throws AccountException {
		em.getTransaction().begin();
		if(em.find(Account.class, accountNo)!=null)
		{
			account=em.find(Account.class, accountNo);
			if(account.getBalance()>amount)
			{
				amount=account.getBalance()-amount;
				account.setBalance(amount);
				System.out.println("Updated Amount: "+account.getBalance());
			}
			else
			{
				System.out.println("You don't have sufficient balance.\nBalance: "+account.getBalance());
			}
		}
		else {
			System.out.println("Use does't exist.");
		}
		
		
		em.getTransaction().commit();
		/*em.close();
		factory.close();*/
		return account;
		
	}

	@Override
	public Account fundTransfer(String accountNo, String accountNo1, double amount) throws AccountException {
		em.getTransaction().begin();
		if(em.find(Account.class, accountNo)!=null && em.find(Account.class, accountNo1)!=null )
		{
			
			account=em.find(Account.class, accountNo);
			
			if(account.getBalance()>amount)
			{
				double amount1=account.getBalance()-amount;
				account.setBalance(amount1);
				
				account=em.find(Account.class, accountNo1);
				amount1=account.getBalance()+amount;
				account.setBalance(amount1);
				System.out.println("Trasaction successfull!!");
				
			}
			else
			{
				System.out.println("You don't have sufficient balance.\nBalance: "+account.getBalance());
			}
		}
		else {
			System.out.println("User not exist");
		}
		
		em.getTransaction().commit();
		/*em.close();
		factory.close();*/
		return account;
	}
	

}
